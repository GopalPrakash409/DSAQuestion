// Problem Link : https://codeforces.com/problemset/problem/805/A

#include<bits/stdc++.h>

using namespace std;

int main() 
{
    int n,m;
    cin >> n >> m;
    if(n != m)
        cout << 2 << endl;
    else
        cout << n << endl;
    return 0;
}
