// Problem Link : https://codeforces.com/contest/1553/problem/A
#include<bits/stdc++.h>

using namespace std;

int main() 
{
    int t;
    cin >> t;
    for (int z = 1; z <= t; z++){
        int n;
        cin >> n;

        cout << (n+1)/10 << endl;
    }
    return 0;
}
